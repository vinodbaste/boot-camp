def mul(a,b):
    print("multiplication",a*b)