def dimul(a,b):
    print("modulus",a%b)