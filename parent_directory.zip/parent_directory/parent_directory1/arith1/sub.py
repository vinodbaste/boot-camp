def sub(a,b):
    print("subtract", a-b)