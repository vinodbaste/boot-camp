def add(a,b):
    print("Addition",a+b)